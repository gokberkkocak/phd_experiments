use rust_glucose::bindings::CGlucose;
use rust_glucose::add_clause_to_glucose_solver;
use rust_glucose::add_assumptions_to_glucose_solver;
use rust_glucose::init_glucose_solver;
use rust_glucose::run_glucose;
use rust_glucose::get_glucose_solver_stats;
use rust_glucose::get_glucose_solution;
use rust_glucose::set_glucose_rnd_seed;
use rust_glucose::get_glucose_solver_nb_learnt;

#[no_mangle]
pub extern "system" fn Java_savilerow_InteractiveGlucoseSATSolver_initSolver(_env: JNIEnv, _class: JClass) -> jlong {
    let s: *mut CGlucose = init_glucose_solver();
    s as jlong
}

#[no_mangle]
pub extern "system" fn Java_savilerow_InteractiveGlucoseSATSolver_addClauseToSolver(
    env: JNIEnv,
    _class: JClass,
    s: jlong,
    clause: jintArray,
) -> jlong {
    let s = s as *mut CGlucose;
    let size: usize = env.get_array_length(clause).unwrap() as usize;
    let mut rust_clause = vec![0; size];
    env.get_int_array_region(clause, 0.into(), rust_clause.as_mut_slice()).unwrap();
    add_clause_to_glucose_solver(s, rust_clause);
    0 as jlong
}

#[no_mangle]
pub extern "system" fn Java_savilerow_InteractiveGlucoseSATSolver_addAssumptionsToSolver(
    env: JNIEnv,
    _class: JClass,
    s: jlong,
    assumptions: jintArray,
) -> jlong {
    let s = s as *mut CGlucose;
    let size: usize = env.get_array_length(assumptions).unwrap() as usize;
    let mut rust_assumptions = vec![0; size];
    env.get_int_array_region(assumptions, 0.into(), rust_assumptions.as_mut_slice()).unwrap();
    add_assumptions_to_glucose_solver(s, rust_assumptions);
    0 as jlong
}

#[no_mangle]
pub extern "system" fn Java_savilerow_InteractiveGlucoseSATSolver_runSolver(
    env: JNIEnv,
    _class: JClass,
    s: jlong,
    j: JObject,
    nb: jlong
) -> jlong {
    let s = s as *mut CGlucose;
    let ret = run_glucose(s);
    // there is a solution
    if ret == 0 {
        let rust_model = get_glucose_solution(s, nb as usize);
        let j_solution = env.new_int_array(rust_model.len() as i32).unwrap();
        env
            .set_int_array_region(j_solution, 0, rust_model.as_slice())
            .unwrap();
        let _sol = env.call_method(j, JAVA_CALLBACK_METHOD_DYN, JAVA_CALLBACK_METHOD_SIGN, &[JValue::from(JObject::from(j_solution))]).unwrap();
        return 0 as jlong
    }
    1 as jlong
}

#[no_mangle]
pub extern "system" fn Java_savilerow_InteractiveGlucoseSATSolver_getSolverStats(
    _env: JNIEnv,
    _class: JClass,
    s: jlong,
) -> jlong {
    let s = s as *mut CGlucose;
    let v = get_glucose_solver_stats(s);
    v as jlong
}

#[no_mangle]
pub extern "system" fn Java_savilerow_InteractiveGlucoseSATSolver_setRndSeed(
    _env: JNIEnv,
    _class: JClass,
    s: jlong,
    seed: jlong
) -> jlong {
    let s = s as *mut CGlucose;
    set_glucose_rnd_seed(s, seed as f64);
    0 as jlong
}

#[no_mangle]
pub extern "system" fn Java_savilerow_InteractiveGlucoseSATSolver_getNbLearntClauses(
    _env: JNIEnv,
    _class: JClass,
    s: jlong
) -> jlong {
    let s = s as *mut CGlucose;
    let l = get_glucose_solver_nb_learnt(s);
    l as jlong
}