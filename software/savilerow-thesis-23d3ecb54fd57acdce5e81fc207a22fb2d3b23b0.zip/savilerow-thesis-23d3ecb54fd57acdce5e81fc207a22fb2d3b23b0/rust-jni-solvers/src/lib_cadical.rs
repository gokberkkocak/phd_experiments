use rust_cadical::bindings::CCaDiCaL;
use rust_cadical::add_clause_to_cadical_solver;
use rust_cadical::add_assumptions_to_cadical_solver;
use rust_cadical::init_cadical_solver;
use rust_cadical::run_cadical;
use rust_cadical::get_cadical_solver_stats;
use rust_cadical::get_cadical_solution;
use rust_cadical::set_cadical_rnd_seed;
use rust_cadical::get_cadical_nb_learnt_clauses;


#[no_mangle]
pub extern "system" fn Java_savilerow_InteractiveCadicalSATSolver_initSolver(_env: JNIEnv, _class: JClass) -> jlong {
    let s: *mut CCaDiCaL = init_cadical_solver();
    s as jlong
}

#[no_mangle]
pub extern "system" fn Java_savilerow_InteractiveCadicalSATSolver_addClauseToSolver(
    env: JNIEnv,
    _class: JClass,
    s: jlong,
    clause: jintArray,
) -> jlong {
    let s = s as *mut CCaDiCaL;
    let size: usize = env.get_array_length(clause).unwrap() as usize;
    let mut rust_clause = vec![0; size];
    env.get_int_array_region(clause, 0.into(), rust_clause.as_mut_slice()).unwrap();
    add_clause_to_cadical_solver(s, rust_clause);
    0 as jlong
}

#[no_mangle]
pub extern "system" fn Java_savilerow_InteractiveCadicalSATSolver_addAssumptionsToSolver(
    env: JNIEnv,
    _class: JClass,
    s: jlong,
    assumptions: jintArray,
) -> jlong {
    let s = s as *mut CCaDiCaL;
    let size: usize = env.get_array_length(assumptions).unwrap() as usize;
    let mut rust_assumptions = vec![0; size];
    env.get_int_array_region(assumptions, 0.into(), rust_assumptions.as_mut_slice()).unwrap();
    add_assumptions_to_cadical_solver(s, rust_assumptions);
    0 as jlong
}

#[no_mangle]
pub extern "system" fn Java_savilerow_InteractiveCadicalSATSolver_runSolver(
    env: JNIEnv,
    _class: JClass,
    s: jlong,
    j: JObject,
    nb: jlong
) -> jlong {
    let s = s as *mut CCaDiCaL;
    let ret = run_cadical(s);
    // there is a solution if ret is 10
    if ret == 10{
        let rust_model = get_cadical_solution(s, nb as usize);
        let j_solution = env.new_int_array(rust_model.len() as i32).unwrap();
        env
            .set_int_array_region(j_solution, 0, rust_model.as_slice())
            .unwrap();
        let _sol = env.call_method(j, JAVA_CALLBACK_METHOD_DYN, JAVA_CALLBACK_METHOD_SIGN, &[JValue::from(JObject::from(j_solution))]).unwrap();
        return 0 as jlong
    }
    1 as jlong
}

#[no_mangle]
pub extern "system" fn Java_savilerow_InteractiveCadicalSATSolver_getSolverStats(
    _env: JNIEnv,
    _class: JClass,
    s: jlong,
) -> jlong {
    let s = s as *mut CCaDiCaL;
    let v = get_cadical_solver_stats(s);
    v as jlong
}

#[no_mangle]
pub extern "system" fn Java_savilerow_InteractiveCadicalSATSolver_setRndSeed(
    _env: JNIEnv,
    _class: JClass,
    s: jlong,
    seed: jlong
) -> jlong {
    let s = s as *mut CCaDiCaL;
    set_cadical_rnd_seed(s, seed);
    0 as jlong
}

#[no_mangle]
pub extern "system" fn Java_savilerow_InteractiveCadicalSATSolver_getNbLearntClauses(
    _env: JNIEnv,
    _class: JClass,
    s: jlong
) -> jlong {
    let s = s as *mut CCaDiCaL;
    let l = get_cadical_nb_learnt_clauses(s);
    l as jlong
}
