use core::mem;

use jni::JNIEnv;
use jni::objects::{JClass, JObject, JValue};
use jni::sys::{jintArray, jdoubleArray, jlong, jobject};

// name of the java callback method.
const JAVA_CALLBACK_METHOD_DYN: &str = "handleFreshSolution";
// method signature of the java callback method.
// javap -s {classname} will give this
// const JAVA_CALLBACK_METHOD_SIGN: &str = "([I)[I";
const JAVA_CALLBACK_METHOD_SIGN: &str = "([I)V";


include!("lib_cadical.rs");

include!("lib_glucose.rs");

include!("lib_nbc.rs");
