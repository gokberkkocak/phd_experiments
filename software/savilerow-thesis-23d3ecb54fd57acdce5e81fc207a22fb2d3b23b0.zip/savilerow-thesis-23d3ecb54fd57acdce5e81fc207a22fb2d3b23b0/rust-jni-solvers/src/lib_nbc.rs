use rust_nbc::add_clause_to_nbc_solver;
use rust_nbc::add_assumptions_to_nbc_solver;
use rust_nbc::init_nbc_solver;
use rust_nbc::run_nbc;
use rust_nbc::solver;
use rust_nbc::solver_nvars;
use rust_nbc::set_nb_of_solutions;
use rust_nbc::get_solver_stats;
use rust_nbc::set_nbc_solver_rnd_seed;
use rust_nbc::get_nbc_nb_learnt_clauses;

#[repr(C)]
struct JavaData {
    java_env: *mut jni::sys::JNIEnv,
    solution: jintArray,
    java_callback_object: jobject,
}

#[no_mangle]
pub extern "system" fn Java_savilerow_InteractiveAllMinisatSATSolver_initSolver(_env: JNIEnv, _class: JClass) -> jlong {
    let s: *mut solver = init_nbc_solver();
    s as jlong
}

#[no_mangle]
pub extern "system" fn Java_savilerow_InteractiveAllMinisatSATSolver_addClauseToSolver(
    env: JNIEnv,
    _class: JClass,
    s: jlong,
    clause: jintArray,
) -> jlong {
    let s = s as *mut solver;
    let size: usize = env.get_array_length(clause).unwrap() as usize;
    let mut rust_clause = vec![0; size];
    env.get_int_array_region(clause, 0.into(), rust_clause.as_mut_slice()).unwrap();
    add_clause_to_nbc_solver(s, rust_clause);
    0 as jlong
}

#[no_mangle]
pub extern "system" fn Java_savilerow_InteractiveAllMinisatSATSolver_addAssumptionsToSolver(
    env: JNIEnv,
    _class: JClass,
    s: jlong,
    assumptions: jintArray,
) -> jlong {
    let s = s as *mut solver;
    let size: usize = env.get_array_length(assumptions).unwrap() as usize;
    let mut rust_assumptions = vec![0; size];
    env.get_int_array_region(assumptions, 0.into(), rust_assumptions.as_mut_slice()).unwrap();
    add_assumptions_to_nbc_solver(s, rust_assumptions);
    0 as jlong
}


#[no_mangle]
pub extern "system" fn Java_savilerow_InteractiveAllMinisatSATSolver_getNbSolutionsFromSolver(
    _env: JNIEnv,
    _class: JClass,
    s: jlong,
) -> jlong {
    let s = s as *mut solver;
    let nb = unsafe { (*s).stats.tot_solutions };
    nb as jlong
}

#[no_mangle]
pub extern "system" fn Java_savilerow_InteractiveAllMinisatSATSolver_runSolver(
    env: JNIEnv,
    _class: JClass,
    s: jlong,
    j: JObject,
) -> jlong {
    let s = s as *mut solver;
    //get nb of vars to determine the size of jintarray
    let nb_vars = unsafe { solver_nvars(s) };
    let java_data = Box::into_raw(Box::new(JavaData {
        java_env: env.get_native_interface(),
        solution: env.new_int_array(nb_vars).unwrap(),
        java_callback_object: j.into_inner(),
    }));
    // register the callback
    unsafe { nbc_register_callback(java_data, nbc_callback) };
    run_nbc(s);
    0 as jlong
}

#[no_mangle]
pub extern "system" fn Java_savilerow_InteractiveAllMinisatSATSolver_setNbSolutions(
    _env: JNIEnv,
    _class: JClass,
    s: jlong,
    k: jlong
) -> jlong {
    let s = s as *mut solver;
    set_nb_of_solutions(s, k as u64);
    0 as jlong
}

#[no_mangle]
pub extern "system" fn Java_savilerow_InteractiveAllMinisatSATSolver_getSolverStats(
    env: JNIEnv,
    _class: JClass,
    s: jlong,
) -> jdoubleArray {
    let s = s as *mut solver;
    let v = get_solver_stats(s);
    let j_stats_array = env.new_double_array(v.len() as i32).unwrap();
    env.set_double_array_region(j_stats_array, 0, v.as_slice()).unwrap();
    j_stats_array
}

#[no_mangle]
pub extern "system" fn Java_savilerow_InteractiveAllMinisatSATSolver_setRndSeed(
    _env: JNIEnv,
    _class: JClass,
    s: jlong,
    seed: jlong
) -> jlong {
    let s = s as *mut solver;
    set_nbc_solver_rnd_seed(s, seed as f64);
    0 as jlong
}

#[no_mangle]
pub extern "system" fn Java_savilerow_InteractiveAllMinisatSATSolver_getNbLearntClauses(
    _env: JNIEnv,
    _class: JClass,
    s: jlong
) -> jlong {
    let s = s as *mut solver;
    let l = get_nbc_nb_learnt_clauses(s);
    l as jlong
}

extern "C" fn nbc_callback(java_data: *mut JavaData, s: *mut solver) {
    let box_java_data = unsafe { Box::from_raw(java_data) };
    let j_env: JNIEnv = unsafe { JNIEnv::from_raw(box_java_data.java_env).unwrap() };
    let j_solution = box_java_data.solution;
    let j_callback_object = box_java_data.java_callback_object;
    // C vec to Rust vec without copying, need to release rust vec otherwise it will give double free/corruption.
    let rust_vec: Vec<i32> = unsafe {
        Vec::from_raw_parts(
            (*s).native_solution.ptr,
            (*s).native_solution.size as usize,
            (*s).native_solution.cap as usize,
        )
    };
    // mem copy to jintarray
    j_env
        .set_int_array_region(j_solution, 0, rust_vec.as_slice())
        .unwrap();
    // Put the array with lifetime struct and pass into the solution handler
    let _sol = j_env
        .call_method(
            JObject::from(j_callback_object),
            JAVA_CALLBACK_METHOD_DYN,
            JAVA_CALLBACK_METHOD_SIGN,
            &[JValue::from(JObject::from(j_solution))],
        )
        .unwrap();
    // j_env.call_static_method(j_class, JAVA_CALLBACK_METHOD_STATIC, JAVA_CALLBACK_METHOD_SIGN, &[JValue::from(JObject::from(j_solution))]).unwrap();
    // let's forget box/vec -- rust would drop it. we need that data later
    let _raw_java_data = Box::into_raw(box_java_data);
    mem::forget(rust_vec);
}

extern "C" {
    fn nbc_register_callback(
        target: *mut JavaData,
        cb: extern "C" fn(*mut JavaData, *mut solver),
    ) -> ::std::os::raw::c_int;
}
