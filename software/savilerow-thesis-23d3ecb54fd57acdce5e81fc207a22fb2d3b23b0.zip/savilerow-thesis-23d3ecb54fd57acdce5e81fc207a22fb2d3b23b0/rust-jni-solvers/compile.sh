#!/bin/bash
# Check rust and cargo
if ! [ -x "$(command -v cargo)" ]; then
    echo "rust and cargo are not installed, installing it now."
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
fi
cargo build --release --features generate-bindings
# Platform detection
os=$(uname)
libfile="librust_jni_solvers"
if [[ "$os" == 'Linux' ]]; then
   libfile="$libfile.so"
elif [[ "$os" == 'Darwin' ]]; then
   libfile="$libfile.dylib"
fi
cp target/release/$libfile ../lib/
