#!/bin/bash

# A very simple script to make a regression test out of a (passing) problem instance 
# for use (e.g.) directly after fixing an issue from the issue tracker. 

./savilerow $1

cp $1 test/test-instances/
touch test/test-instances/$1.param
cp $1.minion test/test-instances/$1.param.minion.expected

hg add test/test-instances/$1
hg add test/test-instances/$1.param
hg add test/test-instances/$1.param.minion.expected


