#!/usr/bin/env python3 -tt

# Second version of regression test script. Translates instances in a set of 
# directories.

# The -heavy version tests various flag settings compared to -O0

import os, sys
from compare import compareMinionFiles 

# each item in batches is a tuple (dirname, extension, savile row options, check firstsol, check allsols) 

# List of problems that produce domains that are too big for SAT encoding. 
notest=["diet.eprime", "grocery.eprime", "magicSequence.eprime", "pegSolitaireState.eprime"]


batches=[\
("test-instances/", ".eprime", "-O0 -sat -test-solutions -cnflimit 100000000", True, False),\
("test-instances/", ".eprime", "-O0 -deletevars -sat -test-solutions -cnflimit 100000000", True, False),\
("test-instances/", ".eprime", "-O0 -deletevars -reduce-domains -sat -test-solutions -cnflimit 100000000", True, False),\
("test-instances/", ".eprime", "-O0 -deletevars -reduce-domains -reduce-domains-extend -sat -test-solutions -cnflimit 100000000", True, False),\
("test-instances/", ".eprime", "-O0 -deletevars -reduce-domains -aggregate -sat -test-solutions -cnflimit 100000000", True, False),\
("test-instances/", ".eprime", "-O3 -sat -test-solutions -cnflimit 100000000", True, False),\
("test-instances/", ".eprime", "-O3 -maxsat -test-solutions -cnflimit 100000000", True, False),\
]

failed_tests=0
fails=[]
total_tests=0

#for batch in batches:
directory=batches[0][0]
extension=batches[0][1]
print("**** TESTING %s/*%s INSTANCES ****"%(directory, extension))
filelist=os.listdir(directory)
filelist.sort()
for filename in filelist:
    if filename[-len(extension):]==extension and (filename not in notest):
        print("-"*80)
        print("Testing "+filename)
        
        # find corresponding parameter files, if any -- start with filename, end with param.
        parameters=filter(lambda a: a[:len(filename)]==filename, os.listdir(directory))
        parameters=filter(lambda a: a[-6:]==".param", parameters)
        parameters=list(map(lambda a: os.path.join(directory, a), parameters))
        
        fullfilename=os.path.join(directory, filename)
        # everything except the param file
        command_test=["../savilerow %s -in-eprime %s -run-solver -out-solution s%d "%(batches[i][2], fullfilename, i) for i in range(len(batches))]
        command_baseline="../savilerow -O0 -in-eprime %s -run-solver -out-solution sb "%(fullfilename)
        
        # baseline runs the same version of SR but with no extra flags.
        
        if not parameters:
            parameters=[fullfilename]   # dummy value, go round the loop once.
        for p in parameters:
            if p==fullfilename:
                cmd_test=[command_test[i]+" -out-minion "+p+".minion.test"+str(i)+" -out-gecode "+p+".fzn.test"+str(i) for i in range(len(command_test))]
                cmd_baseline=command_baseline+" -out-minion "+p+".minion.baseline"
            else:
                cmd_test=[command_test[i]+" -in-param "+p+" -out-minion "+p+".minion.test"+str(i)+" -out-gecode "+p+".fzn.test"+str(i) for i in range(len(command_test))]
                cmd_baseline=command_baseline+" -in-param "+p+" -out-minion "+p+".minion.baseline"
            
            for i in range(len(batches)):
                if os.path.exists("s%d"%i):
                    os.remove("s%d"%i)
            if os.path.exists("sb"):
                os.remove("sb")
            
            print("About to run: "+str(cmd_test+[cmd_baseline]))
            
            for cmdline in cmd_test+[cmd_baseline]:
                os.system(cmdline)
            
            # for each non-baseline run, check the outcome. 
            for i in range(len(cmd_test)):
                si="s%d"%i
                if os.path.exists(si) and not os.path.exists("sb"):
                    print("ERROR: translating %s"%(filename))
                    print("ERROR: Version under test produced a solution when baseline did not.")
                    failed_tests+=1
                    fails.append(command_test)
                elif os.path.exists("sb") and not os.path.exists(si):
                    print("ERROR: translating %s"%(filename))
                    print("ERROR: Version under test did not produce a solution when baseline did.")
                    failed_tests+=1
                    fails.append(command_test)
                elif os.path.exists(si):
                    s1=open(si, "r").readlines()
                    s2=open("sb", "r").readlines()
                    # filter out comment lines. 
                    s1=filter(lambda x: x[0]!='$', s1)
                    s2=filter(lambda x: x[0]!='$', s2)
                    
                    # Can't do the following when testing SAT
                    
                    if s1!=s2 and False:
                        print("ERROR: translating %s"%(filename))
                        print("ERROR: Different solutions.")
                        print("Solution of test version:")
                        print(s1)
                        print("Solution of baseline version:")
                        print(s2)
                        failed_tests+=1
                    else:
                        print("OK: translating %s"%filename)
                else:
                    print("OK: both versions produced no solution when translating %s"%filename)
                
                total_tests+=1
                print("Failed %d of %d so far."%(failed_tests, total_tests))


open("fail_count.txt", "w").write("YVALUE=%d\n"%failed_tests)

print("Number of failed tests: %d"%(failed_tests))
print("Failed test cases: "+str(fails))

if failed_tests>0:
    sys.exit(1)
else:
    sys.exit(0)

