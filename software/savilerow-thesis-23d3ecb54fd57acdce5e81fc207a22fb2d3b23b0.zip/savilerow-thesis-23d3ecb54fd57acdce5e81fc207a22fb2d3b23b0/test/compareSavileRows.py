#!/usr/bin/python -tt

# Compares the Minion performance (time and nodes) of two instances of SR. 


import os, sys

# each item in batches is a tuple (dirname, jarfile, extension, savile row options, check firstsol, check allsols) 

baseline=("test-instances/", "../savilerow.jar", ".eprime", "-deletevars")
test=("test-instances/", "../savilerow.jar", ".eprime", "-extra-cse -deletevars")

MINION_BIN="minion"

directory=baseline[0]
extension=baseline[2]
print "**** TESTING %s/*%s INSTANCES ****"%(directory, extension)
filelist=os.listdir(directory)
filelist.sort()

nodes_diff=0

for filename in filelist:
    if filename[-len(extension):]==extension:
        print "-"*80
        print "Testing "+filename
        
        # find corresponding parameter files, if any -- start with filename, end with param.
        parameters=filter(lambda a: a[:len(filename)]==filename, os.listdir(directory))
        parameters=filter(lambda a: a[-6:]==".param", parameters)
        parameters=map(lambda a: os.path.join(directory, a), parameters)
        
        fullfilename=os.path.join(directory, filename)
        # everything except the param file
        command_baseline="java -ea -Xmx2G -jar %s %s -in-eprime %s "%(baseline[1], baseline[3], fullfilename)
        command_test="java -ea -Xmx2G -jar %s %s -in-eprime %s "%(test[1], test[3], fullfilename)
        
        
        if not parameters:
            parameters=[fullfilename]   # dummy value, go round the loop once.
        for p in parameters:
            if p==fullfilename:
                cmd_baseline=command_baseline
                cmd_test=command_test
            else:
                cmd_baseline=command_baseline+" -in-param "+p
                cmd_test=command_test+" -in-param "+p
            
            cmd_baseline+=" -m "+MINION_BIN+" -out-info info.baseline" 
            print "About to run: "+cmd_baseline
            
            os.system(cmd_baseline)
            
            cmd_test+=" -m "+MINION_BIN+" -out-info info.test" 
            print "About to run: "+cmd_test
            
            os.system(cmd_test)
            
            # Compare the two info files -- nodes and time. 
            
            info_baseline=open("info.baseline").readlines()
            info_test=open("info.test").readlines()
            
            info_baseline=[ st.split(":") for st in  info_baseline ]
            info_test=[ st.split(":") for st in  info_test ]
            
            # MinionNodes and MinionTotalTime
            
            for (a, b) in info_baseline:
                if a=="MinionNodes":
                    minnodes_baseline=int(b)
                elif a=="MinionTotalTime":
                    mintime_baseline=float(b)
                    
            for (a, b) in info_test:
                if a=="MinionNodes":
                    minnodes_test=int(b)
                elif a=="MinionTotalTime":
                    mintime_test=float(b)
            
            print "Minion nodes (baseline, test): %d, %d"%(minnodes_baseline, minnodes_test)
            print "Minion times (baseline, test): %f, %f"%(mintime_baseline, mintime_test)
            
            if minnodes_baseline!=minnodes_test:
                print "!"*80
                nodes_diff+=1
                
            

print "Number of nodes-different tests: %d"%(nodes_diff)

