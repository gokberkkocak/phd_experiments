#!/usr/bin/python -tt

# Compares two Minion files. First of all, only textually.
import sys, os, getopt

def partition(splitter, st):
    # split the string on the first instance of splitter
    idx=st.find(splitter)
    if idx==-1:
        return (st[:], "", "")
    else:
        return (st[:idx], splitter, st[idx+len(splitter):])

def compareMinionFiles(filename1, filename2, minionbin="", firstsol=False, allsols=False):
    # return true if the two are the same.
    # First of all, just take out the comment lines and blank lines before comparing.
    # Should allow constraints to be printed in a different order?
    nodelimit=10000000
    if not os.path.exists(filename1):
        if os.path.exists(filename1+".bz2"):
            filename1=filename1+".bz2"
        else:
            return (False, "Minion 1 file missing.")
    
    if not os.path.exists(filename2):
        if os.path.exists(filename2+".bz2"):
            filename2=filename2+".bz2"
        else:
            return (False, "Minion 2 file missing.")
    
    if filename1[:-3]==".bz":
        file1=os.popen("bzcat %s"%filename1).readlines()
    else:
        file1=open(filename1).readlines()
    
    if filename2[:-3]==".bz":
        file2=os.popen("bzcat %s"%filename2).readlines()
    else:
        file2=open(filename2).readlines()
    
    f1=[]
    for l in file1:
        l2=l.strip()
        if len(l2)>0 and l2[0]!="#":
            f1.append(l2)
    
    f2=[]
    for l in file2:
        l2=l.strip()
        if len(l2)>0 and l2[0]!="#":
            f2.append(l2)
    
    if not (f1==f2):
        # do semantic comparison
        if firstsol or allsols:
            assert minionbin!=""
            # Find the first solution/all solutions of each file using Minion.
            if allsols:
                allsoloption="-findallsols"
            else:
                allsoloption=""
            minout1=os.popen("%s %s -noresume -nodelimit %d %s"%(minionbin,filename1,nodelimit,allsoloption)).readlines()
            minout2=os.popen("%s %s -noresume -nodelimit %d %s"%(minionbin,filename2,nodelimit,allsoloption)).readlines()
            
            # Check if 10000000 nodes was enough
            nodes1=filter(lambda a: a[0:12]=="Total Nodes:", minout1)
            nodes2=filter(lambda a: a[0:12]=="Total Nodes:", minout2)
            n1=int(partition(":", nodes1[0])[2])
            n2=int(partition(":", nodes2[0])[2])
            
            if n1==nodelimit or n2==nodelimit:
                return (False, "Minion hit node limit.")
            
            # Extract the Sol: lines
            sol1=filter(lambda a: a[0:4]=="Sol:", minout1)
            sol2=filter(lambda a: a[0:4]=="Sol:", minout2)
            
            # Cut off Sol:
            sol1=map(lambda a: a[4:].strip().split(), sol1)
            sol2=map(lambda a: a[4:].strip().split(), sol2)
            
            sol1=[i for j in sol1 for i in j]
            sol2=[i for j in sol2 for i in j]
            
            if not (sol1==sol2):
                return (False, "Different solution / set of solutions\n"+str(sol1)+"\n"+str(sol2))
        else:
            return (False,"Minion files different")
    return (True, "")



# (optargs, other)=getopt.gnu_getopt(sys.argv, "", ["file1=", "file2=", "minion=", "firstsol", "allsols"])
# 
# if len(other)!=1:
    # print "Usage: compare.py [--minion=<location of minion binary>] [--file1/2=...] [--firstsol] [--allsols]"
    # sys.exit(1)
# 
# filename1=""
# filename2=""
# minionbin=""
# firstsol=False
# allsols=False
# 
# for i in optargs:
    # (a1, a2)=i
    # if a1=="--minion":
        # minionbin=a2
    # elif a1=="--file1":
        # filename1=a2
    # elif a1=="--file2":
        # filename2=a2
    # elif a1=="--firstsol":
        # firstsol=True
    # elif a1=="--allsols":
        # allsols=True
# 
# assert not allsols or not firstsol
# 
# (same, st)=compareMinionFiles(filename1, filename2, minionbin, firstsol, allsols)
# if not same:
    # print st


