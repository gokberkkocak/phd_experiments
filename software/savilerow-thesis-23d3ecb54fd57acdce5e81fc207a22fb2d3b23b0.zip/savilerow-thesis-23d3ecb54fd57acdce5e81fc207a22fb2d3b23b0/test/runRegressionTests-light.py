#!/usr/bin/env python2 -tt

# This script tests savilerow -O0 against the .minion.expected files in the test-instances folder.
# This ensures basic functionality of savilerow is working. The other script (-heavy) is
# responsible for testing everything beyond -O0 (and comparing it to -O0). 

import os, sys
from compare import compareMinionFiles 

# each item in batches is a tuple (dirname, extension, savile row options, check firstsol, check allsols) 

# Switch everything off with -O0
batches=[\
("test-instances/", ".eprime", "-O0", True, False),\
]
MINION_BIN="../bin/minion"

failed_tests=0
fails=[]

for batch in batches:
    directory=batch[0]
    extension=batch[1]
    print "**** TESTING %s/*%s INSTANCES ****"%(directory, extension)
    filelist=os.listdir(directory)
    filelist.sort()
    for filename in filelist:
        if filename[-len(extension):]==extension:
            print "-"*80
            print "Testing "+filename
            
            # find corresponding parameter files, if any -- start with filename, end with param.
            parameters=filter(lambda a: a[:len(filename)]==filename, os.listdir(directory))
            parameters=filter(lambda a: a[-6:]==".param", parameters)
            parameters=map(lambda a: os.path.join(directory, a), parameters)
            
            fullfilename=os.path.join(directory, filename)
            # everything except the param file
            command="../savilerow %s %s "%(batch[2], fullfilename)
            
            if not parameters:
                parameters=[fullfilename]   # dummy value, go round the loop once.
            for p in parameters:
                if p==fullfilename:
                    cmd=command
                else:
                    cmd=command+" "+p
                cmd+=" -out-minion "+p+".minion" 
                print "About to run: "+cmd
                
                if os.path.exists(p+".minion"):
                    os.remove(p+".minion")
                
                os.system(cmd)
                
                (same, st)=compareMinionFiles(p+".minion", \
                    p.replace(".bz2","")+".minion.expected", \
                    minionbin=MINION_BIN, firstsol=batch[3], allsols=batch[4])
                # look for $fail line in essence' file  --- indicates it is supposed to fail the test. 
                if open(fullfilename, "r").readlines().count("$fail\n")>0 :
                    if same:
                        print "ERROR: translating %s"%(filename)
                        print "Succeeded when it was supposed to fail."
                        failed_tests+=1
                        fails.append(filename)
                        print st
                    else:
                        print "OK: translating %s. Failed test it was supposed to fail."%filename
                else:
                    if not same:
                        print "ERROR: translating %s"%(filename)
                        failed_tests+=1
                        fails.append(filename)
                        print st
                    else:
                        print "OK: translating %s"%filename

open("fail_count.txt", "w").write("YVALUE=%d\n"%failed_tests)

print "Number of failed tests: %d"%(failed_tests)
print "Failed test cases: "+str(fails)

if failed_tests>0:
    sys.exit(1)
else:
    sys.exit(0)

