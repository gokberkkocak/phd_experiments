#!/bin/sh

# Install GrallVM CE and set paths
# gu install native-image

./compile-with-isolvers.sh
native-image \
    -cp classes:lib/trove.jar \
    -H:+ReportExceptionStackTraces \
    -H:JNIConfigurationFiles=savilerow-native-jni.conf \
    --no-server \
    savilerow.EPrimeTailor
