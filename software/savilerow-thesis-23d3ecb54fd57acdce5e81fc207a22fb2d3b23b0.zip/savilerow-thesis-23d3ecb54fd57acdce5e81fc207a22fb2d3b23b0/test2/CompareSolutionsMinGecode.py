#!/usr/bin/env python3

import sys

def ReadSolutions(MinionOutput):
    SolutionList = []
    
    linenum = 0

    while linenum < len(MinionOutput):
        if MinionOutput[linenum][:4] == "Sol:":
            currentSolution = []
            while MinionOutput[linenum][:4] == "Sol:":
                currentSolution += [int(x) for x in MinionOutput[linenum][4:].strip().split(' ')]
                linenum = linenum + 1
            SolutionList.append(currentSolution)
        else:
            linenum = linenum + 1

    return SolutionList

def ReadSolutionsGecode(GecodeOutput):
    SolutionList=[]
    if GecodeOutput[0][:17]=="=====UNKNOWN=====":
        return []
    if GecodeOutput[0][:23]=="=====UNSATISFIABLE=====":
        return []
    
    linenum=0
    solution=[]
    while linenum < len(GecodeOutput) :
        line=GecodeOutput[linenum].strip()
        if line == "==========":
            assert solution==[]
            return SolutionList
        elif line == "----------":
            SolutionList.append(solution)
            solution=[]
        else:
            solution.append(int(line.split("=")[1][:-1]))   # What it lacks in readability, it makes up for in lack of elegance.
        linenum+=1
    return SolutionList
    
    
    

minionsols = ReadSolutions(open(sys.argv[1]).readlines())
gecodesols=ReadSolutionsGecode(open(sys.argv[2],"r").readlines())

if len(minionsols) != len(gecodesols) and len(gecodesols)!=1:
    print("WARNING: Different number of solutions when comparing Minion and Gecode")

if bool(len(minionsols)==0) != bool(len(gecodesols)==0):
    print("WARNING: Only one of the solvers did not find a solution")
    exit(0)

# if necessary, truncate the gecode solutions to be the same length as minion ones
# (get rid of aux vars that are not printed by minion)
for i in range(len(gecodesols)):
    gecodesols[i]=gecodesols[i][:len(minionsols[0])]

if len(minionsols)>1 and len(gecodesols)==1:
    # optimisation problem, gecode only printed one solution, minion printed many
    if gecodesols[0] not in minionsols:
        print("Gecode solution not found by Minion (prob. optimisation problem)")
        exit(1)
    exit(0)

# Truncate one or the other list to be the same length
if len(gecodesols)<len(minionsols):
    minionsols=minionsols[:len(gecodesols)]
if len(minionsols)<len(gecodesols):
    gecodesols=gecodesols[:len(minionsols)]


gecodesols=sorted(gecodesols)
minionsols=sorted(minionsols)

if minionsols != gecodesols:
    print("Different solutions")
    exit(1)
exit(0)

