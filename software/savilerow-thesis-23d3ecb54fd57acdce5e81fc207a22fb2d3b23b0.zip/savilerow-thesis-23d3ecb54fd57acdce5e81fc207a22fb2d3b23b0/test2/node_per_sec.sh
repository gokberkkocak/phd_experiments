#!/bin/bash

if [ -z "${DOM_SCRIPTS}" ]; then
    DOM_SCRIPTS=~/dominion-git/dominion/solver/scripts/
fi

ulimit -Sv 2000000

T=$($* -n 1 2>/dev/null | $DOM_SCRIPTS/grab_dom_output.py cpu_time 2>/dev/null ) || { echo -1 -1 ; exit -1; }
NEWT=$(echo 'scale=0; ('$T' + 60)/1' | bc)
( $* -t $NEWT 2>/dev/null | $DOM_SCRIPTS/grab_dom_output.py nodes_per_cpu_sec max_rss 2>/dev/null ) || { echo -1 -1 ; exit -1; }
