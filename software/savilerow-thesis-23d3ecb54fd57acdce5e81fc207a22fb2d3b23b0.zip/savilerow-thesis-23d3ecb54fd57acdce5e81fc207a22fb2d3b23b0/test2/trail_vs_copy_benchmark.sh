#!/bin/bash
rm $1/*.exe
./build_dom_solver.sh $1/*.eprime.dominion --optimise
cp $1/*.eprime.dominion.solver.exe $1/copy.exe
./build_trailing_dom_solver.sh $1/*.eprime.dominion --optimise
cp $1/*.eprime.dominion.solver.exe $1/trail.exe


for i in 5 6 7 8 9 10 12 14 16 18 20 25 30 40 50 60 80 100 200 400 600 800 1000 2000 4000 ; do
echo $i $(./node_per_sec.sh $1/copy.exe --noprintsols -s 0 -p n $i ) $(./node_per_sec.sh $1/trail.exe --noprintsols -s 0 -p n $i )
done
