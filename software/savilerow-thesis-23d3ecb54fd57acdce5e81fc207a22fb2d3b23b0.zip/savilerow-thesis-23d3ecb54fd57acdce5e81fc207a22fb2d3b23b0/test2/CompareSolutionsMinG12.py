#!/usr/bin/env python3

import sys

def ReadSolutions(MinionOutput):
    SolutionList = []
    
    linenum = 0

    while linenum < len(MinionOutput):
        if MinionOutput[linenum][:4] == "Sol:":
            currentSolution = []
            while MinionOutput[linenum][:4] == "Sol:":
                currentSolution += [int(x) for x in MinionOutput[linenum][4:].strip().split(' ')]
                linenum = linenum + 1
            SolutionList.append(currentSolution)
        else:
            linenum = linenum + 1

    return SolutionList

def ReadSolutionsG12(G12Output):
    if G12Output[0][:17]=="=====UNKNOWN=====":
        return []
    if G12Output[0][:17]=="=====UNBOUNDED=====":
        return []
    if G12Output[0][:23]=="=====UNSATISFIABLE=====":
        return []
    
    # one line of values. 
    SolutionList=[]
    solution=[]
    linenum=0
    while linenum<len(G12Output):
        line=G12Output[linenum].strip()
        if line == "----------":
            SolutionList.append(solution)
            solution=[]
        elif line == "==========":
            pass
        else:
            linebits=line.split()
            for j in linebits:
                if j=="true":
                    solution.append(1)
                elif j=="false":
                    solution.append(0)
                else:
                    solution.append(int(j))
        linenum+=1
    return SolutionList
    
    
    

minionsols = ReadSolutions(open(sys.argv[1]).readlines())
g12sols=ReadSolutionsG12(open(sys.argv[2]).readlines())

if len(minionsols) != len(g12sols) and len(g12sols)!=1:
    print("WARNING: Different number of solutions when comparing Minion and Gecode")

if bool(len(minionsols)==0) != bool(len(g12sols)==0):
    print("WARNING: Only one of the solvers did not find a solution")
    exit(0)

# if necessary, truncate the gecode solutions to be the same length as minion ones
# (get rid of aux vars that are not printed by minion)
for i in range(len(g12sols)):
    g12sols[i]=g12sols[i][:len(minionsols[0])]

if len(minionsols)>1 and len(g12sols)==1:
    # optimisation problem, gecode/g12 only printed one solution, minion printed many
    if g12sols[0] not in minionsols:
        print("Gecode solution not found by Minion (prob. optimisation problem)")
        exit(1)
    exit(0)

# Truncate one or the other list to be the same length
if len(g12sols)<len(minionsols):
    minionsols=minionsols[:len(g12sols)]
if len(minionsols)<len(g12sols):
    g12sols=g12sols[:len(minionsols)]


g12sols=sorted(g12sols)
minionsols=sorted(minionsols)

if minionsols != g12sols:
    print("Different solutions")
    exit(1)
exit(0)
