#!/usr/bin/env python3

import sys

def ReadSolutions(MinionOutput):
    SolutionList = []
    
    linenum = 0

    while linenum < len(MinionOutput):
        if MinionOutput[linenum][:4] == "Sol:":
            currentSolution = []
            while MinionOutput[linenum][:4] == "Sol:":
                currentSolution += [int(x) for x in MinionOutput[linenum][4:].strip().split(' ')]
                linenum = linenum + 1
            SolutionList.append(currentSolution)
        else:
            linenum = linenum + 1

    return SolutionList


minionsols = ReadSolutions(open(sys.argv[1]).readlines())

output = eval(open(sys.argv[2],"r").read())
dominionsols = [ t['sol'] for t in output['solutions'] ]

if len(minionsols) != len(dominionsols):
    print("WARNING: Different number of solutions when comparing Minion and Dominion")

minionsols=sorted(minionsols)
dominionsols=sorted(dominionsols)

if len(minionsols) < len(dominionsols) :
    dominionsols=dominionsols[:len(minionsols)]
if len(dominionsols) < len(minionsols) :
    minionsols=minionsols[:len(dominionsols)]

# if necessary, truncate the dominion solutions to be the same length as minion ones
# (get rid of aux vars that are not printed by minion
for i in range(len(minionsols)):
    dominionsols[i]=dominionsols[i][:len(minionsols[i])]


if minionsols != dominionsols:
    print("Different solutions")
    exit(1)


