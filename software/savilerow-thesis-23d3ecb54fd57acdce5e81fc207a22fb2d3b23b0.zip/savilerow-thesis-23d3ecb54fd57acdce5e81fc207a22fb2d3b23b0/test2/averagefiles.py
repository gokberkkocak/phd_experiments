#!/usr/bin/python
# A script which averages the numbers in the named files to make a new file.

import sys
from string import lower
import os.path

infiles= sys.argv[1:]

dat=[]

import csv

for filename in infiles:
    rea=csv.reader(open(filename,"r"), delimiter=' ')
    dlist=[]
    for line in rea:
        if line!=[]:
            dlist.append(line)
    
    dat.append(dlist)


avgtable=[]

colavgidx=range(len(dat[0][0]))

# iterate by row first.
for i in range(len(dat[0])):
    # copy the row from the first file
    avgrow=dat[0][i][:]
    for a in colavgidx:
        collect=[]
        for j in range(len(dat)):
            collect.append(float(dat[j][i][a]))
        #collect.sort()
        #mid=len(collect)//2
        #avgrow[a]=collect[mid]
        #assert len(collect)%2 == 1
        avgrow[a]=sum(collect)/len(collect)
    avgtable.append(avgrow)


for line in avgtable:
    print reduce(lambda x,y:str(x)+" "+str(y), line)


