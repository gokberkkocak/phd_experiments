#!/bin/bash

echo problem,size,blocknodes,blockmem,trailnodes,trailmem >results.csv

sed -e "s/^/Golomb /" golomb_log | sed -e "s/ /,/g" >>results.csv

sed -e "s/^/MagicSquare /" magicsquare_log | sed -e "s/ /,/g" >>results.csv

sed -e "s/^/NQueens1 /" n_queens_2_log | sed -e "s/ /,/g" >>results.csv

sed -e "s/^/NQueens2 /" n_queens_3_log | sed -e "s/ /,/g" >>results.csv

sed -e "s/^/QG3Idem /" qg3idem_log | sed -e "s/ /,/g" >>results.csv
sed -e "s/^/QG3NonIdem /" qg3nonidem_log | sed -e "s/ /,/g" >>results.csv

R --no-save < eval.R 

pdfcrop nodes.pdf

