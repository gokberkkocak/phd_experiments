#!/usr/bin/env python3
import os

# Now doing minmappers - fewer are different
dirs=["n_queens_1", "n_queens_2", "n_queens_3", 
      "quasiGroup3NonIdem",
      "quasiGroup4Idem", "quasiGroup4NonIdem", "quasiGroup5Idem", "quasiGroup5NonIdem",
      "quasiGroup6", "quasiGroup7", "solitaireBattleship",
      "tickTackToe", "langford-new"]

def runexp(s):
    nodes = 0
    cpu_time = 0
    timeout = False
    for i in range(5):
        os.system(s + " > tmp")
        inf = float("inf")
        mappers=eval(open("tmp","r").read())
        nodes = mappers['nodes']
        cpu_time += mappers['cpu_time']
        if 'early_search_finish_reason' in mappers and mappers['early_search_finish_reason']=="time":
            timeout = True
    return { 'nodes' : nodes, 'cpu_time' : cpu_time / 5.0, 'timeout': timeout }


for d in dirs:
    lst=os.listdir(d)
    print(d+" & & & & & & \\\\")
    # find the eprime file
    eprime=False
    for l in lst:
        if l[-7:]==".eprime":
            eprime=l
    
    assert eprime
    #find the param files.
    params=[]
    for l in lst:
        if l[-6:]==".param":
            params.append(l)
    
    os.system("./build_dom_solver.sh --optimise %s/%s.dominion "%(d,eprime))
    os.system("./build_dom_solver.sh --optimise %s/%s.dominion.nomap "%(d,eprime))
    os.system("./build_dom_solver.sh --optimise %s/%s.dominion.minmap "%(d,eprime))
    
    for param in params:
        mappers = runexp("./%s/%s.dominion.solver.exe --cpulimit 1200 %s/%s" %(d, eprime, d, param))
        nomappers = runexp("./%s/%s.dominion.nomap.solver.exe --cpulimit 1200 %s/%s" %(d, eprime, d, param))
        minmappers = runexp("./%s/%s.dominion.minmap.solver.exe --cpulimit 1200 %s/%s" %(d, eprime, d, param))

        timeout = mappers['timeout'] or nomappers['timeout'] or minmappers['timeout']
                
        print("%d & %0.3f & %d & %0.3f & %d & %0.3f & %s \\\\" %(mappers['nodes'], mappers['cpu_time'], nomappers['nodes'], nomappers['cpu_time'], minmappers['nodes'], minmappers['cpu_time'], str(timeout)))
    
    
    
