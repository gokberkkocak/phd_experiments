#!/usr/bin/env bash

# run different problem classes simultaneously to avoid file collision.

./trail_vs_copy_benchmark.sh n_queens_2 >n_queens_2_log_1  &
./trail_vs_copy_benchmark.sh n_queens_3 >n_queens_3_log_1  &
./trail_vs_copy_benchmark.sh quasiGroup3Idem >qg3idem_log_1  &
./trail_vs_copy_benchmark.sh quasiGroup3NonIdem >qg3nonidem_log_1  &
./trail_vs_copy_benchmark.sh golomb >golomb_log_1 &

wait

./trail_vs_copy_benchmark.sh magicSquare >magicsquare_log_1  &
./trail_vs_copy_benchmark.sh n_queens_2 >n_queens_2_log_2  &
./trail_vs_copy_benchmark.sh n_queens_3 >n_queens_3_log_2  &
./trail_vs_copy_benchmark.sh quasiGroup3Idem >qg3idem_log_2  &
./trail_vs_copy_benchmark.sh quasiGroup3NonIdem >qg3nonidem_log_2  &


wait

./trail_vs_copy_benchmark.sh golomb >golomb_log_2 &
./trail_vs_copy_benchmark.sh magicSquare >magicsquare_log_2  &
./trail_vs_copy_benchmark.sh n_queens_2 >n_queens_2_log_3  &
./trail_vs_copy_benchmark.sh n_queens_3 >n_queens_3_log_3  &
./trail_vs_copy_benchmark.sh quasiGroup3Idem >qg3idem_log_3  &


wait


./trail_vs_copy_benchmark.sh quasiGroup3NonIdem >qg3nonidem_log_3  &
./trail_vs_copy_benchmark.sh golomb >golomb_log_3 &
./trail_vs_copy_benchmark.sh magicSquare >magicsquare_log_3  &
./trail_vs_copy_benchmark.sh n_queens_2 >n_queens_2_log_4  &
./trail_vs_copy_benchmark.sh n_queens_3 >n_queens_3_log_4  &


wait

./trail_vs_copy_benchmark.sh quasiGroup3Idem >qg3idem_log_4  &
./trail_vs_copy_benchmark.sh quasiGroup3NonIdem >qg3nonidem_log_4  &
./trail_vs_copy_benchmark.sh golomb >golomb_log_4 &
./trail_vs_copy_benchmark.sh magicSquare >magicsquare_log_4  &
./trail_vs_copy_benchmark.sh n_queens_2 >n_queens_2_log_5  &


wait


./trail_vs_copy_benchmark.sh n_queens_3 >n_queens_3_log_5  &
./trail_vs_copy_benchmark.sh quasiGroup3Idem >qg3idem_log_5  &
./trail_vs_copy_benchmark.sh quasiGroup3NonIdem >qg3nonidem_log_5  &
./trail_vs_copy_benchmark.sh golomb >golomb_log_5 &
./trail_vs_copy_benchmark.sh magicSquare >magicsquare_log_5  &

wait

