if [ -z "${DOM_SCRIPTS}" ]; then
    DOM_SCRIPTS=~/dominion-git/dominion/solver/scripts/
fi

$DOM_SCRIPTS/build_solver.py --nochoice --limit=base.dominion-config --limit=trailing.dominion-config --limit=bool.dominion-config $* ||
$DOM_SCRIPTS/build_solver.py --order=Order --limit=base.dominion-config --limit=trailing.dominion-config --limit=combined.dominion-config $*
